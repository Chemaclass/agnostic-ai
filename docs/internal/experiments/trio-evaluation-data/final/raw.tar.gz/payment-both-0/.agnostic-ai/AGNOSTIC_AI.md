# Project instructions

CLAUDE.md, AGENTS.md, and the other AI tool files are generated from `.private-identity-066-ai/`. Edit `.private-identity-066-ai/AGNOSTIC_AI.md` and the source private-identity-067, then run `private-identity-066-ai sync`.

<!-- Replace this comment with the instructions every AI tool private-identity-053 follow in this project. -->
