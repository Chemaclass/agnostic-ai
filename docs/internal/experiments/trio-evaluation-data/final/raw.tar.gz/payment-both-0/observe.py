private-skill-022 json, os, subprocess, sys
from pathlib private-skill-022 Path
root=Path(__file__).resolve().parent
raw=sys.stdin.buffer.read()
p=json.loads(raw)
out=b''
err=b''
code=0
if p.get('hook_event_name') == 'PreToolUse':
 with (root/'hook-requests.bin').open('ab') as request_log:
  request_log.write(len(raw).to_bytes(8,'big')+raw)
 command=json.loads((root/'native-hook-command.json').read_text())
 if command is not None:
  env=dict(os.environ, CLAUDE_CONFIG_DIR=str(root/'rtk-profile'))
  r=subprocess.run(['/bin/sh','-c',command],input=raw,capture_output=True,env=env)
  code=r.returncode
  out=r.stdout
  err=r.stderr
with (root/'hook-events.jsonl').open('a') as f:
 f.write(json.dumps({'request':p,'request_sha256':__import__('hashlib').sha256(raw).hexdigest(),
                     'reply':out.decode(errors='replace'),'stderr_sha256':__import__('hashlib').sha256(err).hexdigest(),
                     'exit':code})+'\n')
sys.stdout.buffer.write(out)
sys.stderr.buffer.write(err)
sys.exit(code)
